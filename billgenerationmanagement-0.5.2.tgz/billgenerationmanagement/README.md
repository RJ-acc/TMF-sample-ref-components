# Example Bill Generation Management component

This chart packages a reference-style implementation of a `TMFC030 Bill Generation Management` component, following the same broad structure used by the TM Forum sample component repo.

## What it deploys

The chart creates a runnable component shape for:

- the `TMF678 Customer Bill Management` API
- an internal bill-generation engine
- an MCP wrapper over the TMF678 API, enabled by default
- a MongoDB backing store
- a metrics listener that subscribes to TMF678 create and state-change events
- a simplified `TMF669 Party Role Management` API for the security function
- a role initialization job
- a bill-generation initialization job that registers the metrics listener with the API

## Install

```bash
helm upgrade --install pr1 ./charts/BillGenerationManagement -n components
```

The public core API base path is exposed as:

```text
/<release>-billgenerationmanagement/tmf-api/customerBillManagement/v5
```

Example:

```text
/pr1-billgenerationmanagement/tmf-api/customerBillManagement/v5
```

## MCP server

The MCP wrapper is enabled by default. Disable it with:

```bash
helm upgrade --install pr1 ./charts/BillGenerationManagement \
  -n components \
  --set component.MCPServer.enabled=false
```

By default, the chart advertises the normal Streamable HTTP MCP endpoint at `/<release>-billgenerationmanagement/mcp`. That endpoint also keeps legacy SSE compatibility for clients or proxies that open it with `GET`; the SSE message channel is `/<release>-billgenerationmanagement/mcp/messages/`, which path aliases may rewrite for public URLs. Direct in-container `/mcp` and `/sse` routes are available for service-level checks.

## Image values

The default values point to placeholder tags under `ravijangra92/tmf678`. Update them before cluster deployment if you publish the images under a different Docker Hub repository.

## Notes

- The TMF678 API implements the spec-defined list/get surface for `appliedCustomerBillingRate` and `billCycle`.
- `customerBill` supports list/get/patch exactly as defined by TMF678.
- `customerBillOnDemand` supports list/create/get exactly as defined by TMF678.
- The chart uses a single MongoDB instance for the API and the party-role service.
- The bill-generation engine is internal and not exposed as a NodePort service.
